<?php   
$conn=mysql_connect("localhost","root","","sms");
if($conn){
    echo "Connected";
}
else{
    echp "Failed"
}

$username=$_POST['username'];
$password=$_POST['password'];

$data = "INSERT INTO login VALUES('','$username,'$password')";
$check = mysql_query($conn,$data);
if($check){
    echo "Data sended";
}
else{
    echo "Data not send";
}
?>